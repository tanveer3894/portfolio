import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_constants.dart';
import '../sections/about_section.dart';
import '../sections/contact_section.dart';
import '../sections/education_section.dart';
import '../sections/experience_section.dart';
import '../sections/footer_section.dart';
import '../sections/hero_section.dart';
import '../sections/projects_section.dart';
import '../sections/services_section.dart';
import '../sections/skills_section.dart';
import '../widgets/mobile_drawer.dart';
import '../widgets/nav_bar.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final ScrollController _scrollController = ScrollController();
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  final GlobalKey _homeKey = GlobalKey();
  final GlobalKey _aboutKey = GlobalKey();
  final GlobalKey _skillsKey = GlobalKey();
  final GlobalKey _projectsKey = GlobalKey();
  final GlobalKey _experienceKey = GlobalKey();
  final GlobalKey _educationKey = GlobalKey();
  final GlobalKey _servicesKey = GlobalKey();
  final GlobalKey _contactKey = GlobalKey();

  bool _showBackToTop = false;

  @override
  void initState() {
    super.initState();
    _scrollController.addListener(() {
      final show = _scrollController.offset > 400;
      if (show != _showBackToTop) {
        setState(() => _showBackToTop = show);
      }
    });
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  void _scrollTo(GlobalKey key) {
    final context = key.currentContext;
    if (context != null) {
      Scrollable.ensureVisible(
        context,
        duration: const Duration(milliseconds: 600),
        curve: Curves.easeInOutCubic,
      );
    }
  }

  void _showResumeDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: AppColors.cardBackground,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: const BorderSide(color: AppColors.border),
        ),
        title: Row(
          children: const [
            Icon(Icons.description_outlined, color: AppColors.primary),
            SizedBox(width: 10),
            Text(
              'Resume / CV',
              style: TextStyle(color: AppColors.textPrimary, fontSize: 18),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Tanveer Ahmad',
              style: TextStyle(
                fontWeight: FontWeight.w700,
                fontSize: 16,
                color: AppColors.textPrimary,
              ),
            ),
            const SizedBox(height: 4),
            const Text(
              'Flutter Developer | Software Engineer',
              style: TextStyle(color: AppColors.accent, fontSize: 13),
            ),
            const SizedBox(height: 12),
            const Text(
              'Education: BS IT, University of Education Lahore (CGPA 3.35)\n'
              'Experience: Software Engineering Intern at Vantedge AI\n'
              'Key Stack: Flutter, Dart, Firebase, REST APIs, Provider, GetX',
              style: TextStyle(
                color: AppColors.textSecondary,
                fontSize: 13,
                height: 1.5,
              ),
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: AppColors.border),
              ),
              child: const Row(
                children: [
                  Icon(Icons.info_outline, size: 18, color: AppColors.accent),
                  SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Ready to share customized PDF resume upon recruiter inquiry.',
                      style: TextStyle(fontSize: 12, color: AppColors.textSecondary),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Close', style: TextStyle(color: AppColors.textSecondary)),
          ),
          ElevatedButton.icon(
            onPressed: () {
              Navigator.of(context).pop();
              _scrollTo(_contactKey);
            },
            icon: const Icon(Icons.mail_outline, size: 16),
            label: const Text('Contact for CV'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final navItems = [
      NavBarItem(title: 'Home', onTap: () => _scrollTo(_homeKey)),
      NavBarItem(title: 'About', onTap: () => _scrollTo(_aboutKey)),
      NavBarItem(title: 'Skills', onTap: () => _scrollTo(_skillsKey)),
      NavBarItem(title: 'Projects', onTap: () => _scrollTo(_projectsKey)),
      NavBarItem(title: 'Experience', onTap: () => _scrollTo(_experienceKey)),
      NavBarItem(title: 'Education', onTap: () => _scrollTo(_educationKey)),
      NavBarItem(title: 'Services', onTap: () => _scrollTo(_servicesKey)),
      NavBarItem(title: 'Contact', onTap: () => _scrollTo(_contactKey)),
    ];

    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: AppColors.background,
      endDrawer: MobileDrawer(
        items: navItems,
        onResumeTap: _showResumeDialog,
      ),
      body: Stack(
        children: [
          // Background subtle ambient radial glow
          Positioned(
            top: -150,
            left: -150,
            child: Container(
              width: 500,
              height: 500,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [
                    AppColors.primary.withOpacity(0.08),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),
          Positioned(
            top: 800,
            right: -200,
            child: Container(
              width: 600,
              height: 600,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [
                    AppColors.secondary.withOpacity(0.06),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),

          // Main scrollable content
          Column(
            children: [
              NavBar(
                items: navItems,
                onResumeTap: _showResumeDialog,
                onMenuTap: () => _scaffoldKey.currentState?.openEndDrawer(),
              ),
              Expanded(
                child: SingleChildScrollView(
                  controller: _scrollController,
                  child: Column(
                    children: [
                      Container(
                        key: _homeKey,
                        child: HeroSection(
                          onViewProjects: () => _scrollTo(_projectsKey),
                          onContactMe: () => _scrollTo(_contactKey),
                          onDownloadResume: _showResumeDialog,
                        ),
                      ),
                      Container(
                        key: _aboutKey,
                        child: const AboutSection(),
                      ),
                      Container(
                        key: _skillsKey,
                        child: const SkillsSection(),
                      ),
                      Container(
                        key: _projectsKey,
                        child: const ProjectsSection(),
                      ),
                      Container(
                        key: _experienceKey,
                        child: const ExperienceSection(),
                      ),
                      Container(
                        key: _educationKey,
                        child: const EducationSection(),
                      ),
                      Container(
                        key: _servicesKey,
                        child: const ServicesSection(),
                      ),
                      Container(
                        key: _contactKey,
                        child: const ContactSection(),
                      ),
                      FooterSection(
                        onBackToTop: () {
                          _scrollController.animateTo(
                            0,
                            duration: const Duration(milliseconds: 700),
                            curve: Curves.easeInOutCubic,
                          );
                        },
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),

          // Floating Back-to-Top button
          if (_showBackToTop)
            Positioned(
              bottom: 28,
              right: 28,
              child: FloatingActionButton.small(
                backgroundColor: AppColors.cardBackground,
                foregroundColor: AppColors.primary,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                  side: const BorderSide(color: AppColors.border),
                ),
                onPressed: () {
                  _scrollController.animateTo(
                    0,
                    duration: const Duration(milliseconds: 600),
                    curve: Curves.easeInOutCubic,
                  );
                },
                child: const Icon(Icons.keyboard_arrow_up_rounded, size: 22),
              ),
            ),
        ],
      ),
    );
  }
}
