import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_constants.dart';
import '../constants/app_text_styles.dart';
import '../widgets/custom_button.dart';
import '../widgets/glass_card.dart';
import '../widgets/section_header.dart';
import '../widgets/social_icon_button.dart';

class ContactSection extends StatefulWidget {
  const ContactSection({Key? key}) : super(key: key);

  @override
  State<ContactSection> createState() => _ContactSectionState();
}

class _ContactSectionState extends State<ContactSection> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _subjectController = TextEditingController();
  final _messageController = TextEditingController();

  bool _isSending = false;
  bool _isSuccess = false;

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _subjectController.dispose();
    _messageController.dispose();
    super.dispose();
  }

  void _submitForm() async {
    if (_formKey.currentState!.validate()) {
      setState(() => _isSending = true);
      await Future.delayed(const Duration(milliseconds: 900));
      if (mounted) {
        setState(() {
          _isSending = false;
          _isSuccess = true;
        });
        _nameController.clear();
        _emailController.clear();
        _subjectController.clear();
        _messageController.clear();

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            backgroundColor: AppColors.cardBackground,
            content: Row(
              children: [
                Icon(Icons.check_circle_rounded, color: AppColors.success),
                SizedBox(width: 12),
                Text(
                  'Message sent successfully! Thank you for reaching out.',
                  style: TextStyle(color: AppColors.textPrimary),
                ),
              ],
            ),
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final isMobile = screenWidth < 768;

    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: isMobile ? 20 : 40,
        vertical: isMobile ? 50 : 80,
      ),
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: AppConstants.maxContentWidth),
          child: Column(
            children: [
              const SectionHeader(
                badge: 'Get in Touch',
                title: 'Contact & Collaboration',
                subtitle:
                    'Interested in discussing Flutter engineering opportunities, projects, or technical collaboration? Send a message below.',
              ),
              LayoutBuilder(
                builder: (context, constraints) {
                  if (constraints.maxWidth > 880) {
                    return Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Left: Channels & Info
                        Expanded(
                          flex: 4,
                          child: GlassCard(
                            padding: const EdgeInsets.all(32),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text(
                                  "Let's Build Together",
                                  style: TextStyle(
                                    fontSize: 22,
                                    fontWeight: FontWeight.w700,
                                    color: AppColors.textPrimary,
                                  ),
                                ),
                                const SizedBox(height: 12),
                                Text(
                                  'Feel free to connect on GitHub, LinkedIn, or send a message directly using the inquiry form.',
                                  style: AppTextStyles.bodyMedium.copyWith(
                                    color: AppColors.textSecondary,
                                    height: 1.6,
                                  ),
                                ),
                                const SizedBox(height: 32),
                                const Text(
                                  'Profiles & Links:',
                                  style: TextStyle(
                                    fontSize: 13,
                                    fontWeight: FontWeight.w600,
                                    color: AppColors.textPrimary,
                                    letterSpacing: 0.5,
                                  ),
                                ),
                                const SizedBox(height: 14),
                                Row(
                                  children: const [
                                    SocialIconButton(
                                      icon: Icons.code_rounded,
                                      tooltip: 'GitHub: tanveer3894',
                                      url: AppConstants.githubUrl,
                                    ),
                                    SizedBox(width: 12),
                                    SocialIconButton(
                                      icon: Icons.work_outline_rounded,
                                      tooltip: 'LinkedIn Profile',
                                      url: AppConstants.linkedinUrl,
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 32),
                                Container(
                                  padding: const EdgeInsets.all(16),
                                  decoration: BoxDecoration(
                                    color: AppColors.surface,
                                    borderRadius: BorderRadius.circular(12),
                                    border: Border.all(color: AppColors.border),
                                  ),
                                  child: Row(
                                    children: const [
                                      Icon(Icons.location_on_rounded, color: AppColors.primary, size: 20),
                                      SizedBox(width: 12),
                                      Text(
                                        AppConstants.location,
                                        style: TextStyle(
                                          color: AppColors.textPrimary,
                                          fontWeight: FontWeight.w500,
                                          fontSize: 14,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(width: 24),

                        // Right: Contact Form
                        Expanded(
                          flex: 6,
                          child: GlassCard(
                            padding: const EdgeInsets.all(32),
                            child: _buildForm(),
                          ),
                        ),
                      ],
                    );
                  } else {
                    return Column(
                      children: [
                        GlassCard(
                          padding: const EdgeInsets.all(24),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                "Let's Connect",
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.w700,
                                  color: AppColors.textPrimary,
                                ),
                              ),
                              const SizedBox(height: 8),
                              const Text(
                                'Reach out on social profiles or send a direct inquiry.',
                                style: TextStyle(color: AppColors.textSecondary, fontSize: 13),
                              ),
                              const SizedBox(height: 16),
                              Row(
                                children: const [
                                  SocialIconButton(
                                    icon: Icons.code_rounded,
                                    tooltip: 'GitHub',
                                    url: AppConstants.githubUrl,
                                  ),
                                  SizedBox(width: 12),
                                  SocialIconButton(
                                    icon: Icons.work_outline_rounded,
                                    tooltip: 'LinkedIn',
                                    url: AppConstants.linkedinUrl,
                                  ),
                                  SizedBox(width: 16),
                                  Icon(Icons.location_on_outlined, color: AppColors.textMuted, size: 16),
                                  SizedBox(width: 4),
                                  Text(
                                    AppConstants.location,
                                    style: TextStyle(color: AppColors.textMuted, fontSize: 13),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 20),
                        GlassCard(
                          padding: const EdgeInsets.all(24),
                          child: _buildForm(),
                        ),
                      ],
                    );
                  }
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildForm() {
    return Form(
      key: _formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Send a Message',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w700,
              color: AppColors.textPrimary,
            ),
          ),
          const SizedBox(height: 20),
          Row(
            children: [
              Expanded(
                child: TextFormField(
                  controller: _nameController,
                  decoration: const InputDecoration(
                    labelText: 'Your Name',
                    hintText: 'e.g. Alex Morgan',
                    prefixIcon: Icon(Icons.person_outline_rounded, size: 20),
                  ),
                  validator: (v) => (v == null || v.trim().isEmpty) ? 'Please enter your name' : null,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: TextFormField(
                  controller: _emailController,
                  decoration: const InputDecoration(
                    labelText: 'Your Email',
                    hintText: 'e.g. alex@example.com',
                    prefixIcon: Icon(Icons.email_outlined, size: 20),
                  ),
                  validator: (v) {
                    if (v == null || v.trim().isEmpty) return 'Please enter your email';
                    if (!v.contains('@')) return 'Enter a valid email';
                    return null;
                  },
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: _subjectController,
            decoration: const InputDecoration(
              labelText: 'Subject',
              hintText: 'e.g. Flutter Project / Opportunity Inquiry',
              prefixIcon: Icon(Icons.subject_rounded, size: 20),
            ),
            validator: (v) => (v == null || v.trim().isEmpty) ? 'Please enter a subject' : null,
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: _messageController,
            maxLines: 5,
            decoration: const InputDecoration(
              labelText: 'Message',
              hintText: 'Write your message or inquiry here...',
              alignLabelWithHint: true,
            ),
            validator: (v) => (v == null || v.trim().isEmpty) ? 'Please enter your message' : null,
          ),
          const SizedBox(height: 24),
          if (_isSuccess)
            Container(
              padding: const EdgeInsets.all(12),
              margin: const EdgeInsets.only(bottom: 16),
              decoration: BoxDecoration(
                color: AppColors.success.withOpacity(0.12),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: AppColors.success.withOpacity(0.3)),
              ),
              child: const Row(
                children: [
                  Icon(Icons.check_circle_outline, color: AppColors.success, size: 20),
                  SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      'Thank you! Your message has been prepared for dispatch.',
                      style: TextStyle(color: AppColors.success, fontSize: 13),
                    ),
                  ),
                ],
              ),
            ),
          CustomButton(
            text: _isSending ? 'Sending...' : 'Send Message',
            icon: Icons.send_rounded,
            onPressed: _isSending ? () {} : _submitForm,
            isFullWidth: true,
          ),
        ],
      ),
    );
  }
}
